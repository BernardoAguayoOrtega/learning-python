print(1,2,3,4,5)

print(1,2,3,4,5,sep=',')

print(1,2,3,4,5,sep=',',end='.')